

console.log('Loading function');
var aws = require('aws-sdk');
var doc = require('dynamodb-doc');
var dynamodb = new doc.DynamoDB();


var sqs = new aws.SQS();
var Twitter = require('twitter');



exports.handler = function(event, context) {
  console.log('Received event:', JSON.stringify(event, null, 2));
  var token = event.token;
  var secret = event.secret;

  var client = new Twitter({
    consumer_key: 'oGbPqpQeXUojn7macV7Ze9HvO',
    consumer_secret: 'iJDZtadyNK6BwXB49xszyBI6y748iERGEmUQM3veXNlcmKzqwJ',
    access_token_key: token,
    access_token_secret: secret
  });

  client.get('favorites/list', function(error, tweets, response) {
		if(error) {
      console.log(error);
    } else {
      console.log(response);  // Raw response object.
      tweets.map( function(item) {
        console.log("-------" + item);
      })
    }
    context.succeed(event.key1);
 });

        
    function checkTip() {
      var params = {};
      var hashRangeKey = {"ObjectID": "5156728514", "FromUserID": "2767b987-0bb2-43ca-b000-b9552a009a6e"};
    
      params.TableName = "TipperTips";
      params.Key = hashRangeKey;

      dynamodb.getItem(params, function(err, data) {
        if (err) {
            console.log(err, err.stack); // an error occurred
            context.fail('Something went wrong');
        } else {
            console.log(data);           // successful response
            if (data.length > 0) {
                console.log("Found a record")
            } else {
                //var message = { "TweetID": event[:target_object][:id_str], "FromTwitterID": event[:source][:id_str], "ToTwitterID": event[:target][:id_str] };
                //var params = {"QueueUrl": "https://sqs.us-east-1.amazonaws.com/080383581145/TipperNewTip", "MessageBody": JSON.stringify({}) };
                //sqs.sendMessage(params, function(err, data) {
                //    if (err) console.log(err, err.stack); // an error occurred
                //    else     console.log(data);           // successful response
                //});
            }
            context.succeed(event.key1);  // Echo back the first key value
        }
      });
    }
    
    
};